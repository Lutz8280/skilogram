# skilogram
Домашнее задание с уроков skillup
